import React, { Component } from 'react';


class Categoria extends Component {
    render() {

        return (
            <div>
                <CadastroCategoria />
            </div>
        )
    }
}

class CadastroCategoria extends React.Component {
    constructor(props) {
        super(props);
        this.handleSalvar = this.handleSalvar.bind(this);
    }

    handleSalvar(){
        const nome = document.getElementById ( 'categoria-nome' );
        const descricao = document.getElementById ( 'categoria-descricao' );


        fetch('http://localhost:8080/categorias', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                "id":"",
                "nome":nome.value,
                "descricao":descricao.value
            })
        })
    }

    render(){
        return (
            
            <form id="competicao-form">
                <label>Nome:</label>
                <input
                    id="categoria-nome"
                    type="text"
                    name="nome"
                />
                <br/>
                <label>Descricao:</label>
                <input
                    id="categoria-descricao"
                    type="text"
                    name="descricao"
                />
                <button onClick={this.handleSalvar}>
                    Salvar
                </button>
            </form>

        )
    }
}

export default Categoria;