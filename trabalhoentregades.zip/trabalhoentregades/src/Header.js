import React, { Component } from 'react';
import { Link } from 'react-router-dom'


class Header extends Component {

    render() {
        return (
            <header>
                <nav>
                    <ul>
                        <li><Link exact to='/'>Home</Link></li>
                        <li><Link to='/Categorias'>Cadastros de Categoria</Link></li>
                        <li><Link to='/CategoriaDeletar'>Deletar Categoria</Link></li>
                        <li><Link to='/Criterios'>Cadastros de Critérios</Link></li>
                        <li><Link to='/Alternativas'>Cadastros de Alternativa</Link></li>
                        <li><Link to='/Equipes'>Cadastros de Equipes</Link></li>
                        <li><Link to='/Integrante'>Cadastros de Integrante</Link></li>
                        <li><Link to='/Juiz'>Cadastros de Juiz</Link></li>
                        <li><Link to='/Temporada'>Cadastros de Temporada</Link></li>
                        <li><Link to='/Arena'>Cadastros de Arena</Link></li>
                        <li><Link to='/Competicao'>Cadastros de Competição</Link></li>
                        <li><Link to='/SalaAvaliacao'>Cadastros de Sala de Avaliação</Link></li>
                    </ul>
                </nav>
            </header>
        )
    }
}

export default Header;