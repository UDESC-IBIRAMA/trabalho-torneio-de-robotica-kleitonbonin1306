import React, { Component } from 'react';

class Criterio extends Component {
    render() {

        return (
            <div>
                <CadastroCriterio />
            </div>
        )
    }
}

class CadastroCriterio extends React.Component {
    constructor(props) {
        super(props);
        this.handleSalvar = this.handleSalvar.bind(this);
    }

    handleSalvar(){
        const nome = document.getElementById ( 'criterio-nome' );
        const descricao = document.getElementById ( 'criterio-descricao' );
        const categoria = document.getElementById ( 'criterio-categoria' );


        fetch('http://localhost:8080/criterios', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                "id":"",
                "nome":nome.value,
                "descricao":descricao.value,
                "categoria":{"id":categoria.value}
            })
        })
    }

    render(){
        return (
            
            <form id="competicao-form">
                <label>Nome:</label>
                <input
                    id="criterio-nome"
                    type="text"
                    name="nome"
                />
                <br/>
                <label>Descricao:</label>
                <input
                    id="criterio-descricao"
                    type="text"
                    name="descricao"
                />
                <br/>
                <label>Categoria:</label>
                <input
                    id="criterio-categoria"
                    type="number"
                    name="categoria"
                />
                <button onClick={this.handleSalvar}>
                    Salvar
                </button>
            </form>


        )
    }
}

export default Criterio;