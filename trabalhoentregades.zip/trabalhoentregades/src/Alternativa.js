import React, { Component } from 'react';

class Alternativa extends Component {
    render() {

        return (
            <div>
                <CadastroAlternativa />
            </div>
        )
    }
}

class CadastroAlternativa extends React.Component {
    constructor(props) {
        super(props);
        this.handleSalvar = this.handleSalvar.bind(this);
    }

    handleSalvar(){
        const valor = document.getElementById ( 'alternativa-valor' );
        const criterio = document.getElementById ( 'alternativa-criterio' );


        fetch('http://localhost:8080/alternativas', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                "id":"",
                "valor":valor.value,
                "criterio":{"id":criterio.value}
            })
        })
    }

    render(){
        return (
            
            <form id="competicao-form">
                <label>Valor:</label>
                <input
                    id="alternativa-valor"
                    type="number"
                    name="valor"
                />
                <br/>
                <label>Criterio:</label>
                <input
                    id="alternativa-criterio"
                    type="number"
                    name="criterio"
                />
                <button onClick={this.handleSalvar}>
                    Salvar
                </button>
            </form>

        )
    }
}

export default Alternativa;