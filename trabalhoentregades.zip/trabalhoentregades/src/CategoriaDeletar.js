import React, { Component } from 'react';


class CategoriaDeletar extends Component {
    render() {

        return (
            <div>
                <DeletarCategoria />
            </div>
        )
    }
}

class DeletarCategoria extends React.Component {
    constructor(props) {
        super(props);
        this.handleSalvar = this.handleSalvar.bind(this);
    }

    handleSalvar(){
        const id = document.getElementById ( 'categoria-id' );


        fetch('http://localhost:8080/categorias/', {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({"id":id.value})
        })
    }

    render(){
        return (
            
            <form id="competicao-form">
                <label>id:</label>
                <input
                    id="categoria-id"
                    type="number"
                    name="nome"
                />
                <button onClick={this.handleSalvar}>
                    Salvar
                </button>
            </form>

        )
    }
}

export default CategoriaDeletar;