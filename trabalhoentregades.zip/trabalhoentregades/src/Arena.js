import React, { Component } from 'react';

class Arena extends Component {
    render() {

        return (
            <div>
                <CadastroArena />
            </div>
        )
    }
}

class CadastroArena extends React.Component {
    constructor(props) {
        super(props);
        this.handleSalvar = this.handleSalvar.bind(this);
    }

    handleSalvar(){
        const nome = document.getElementById ( 'arena-nome' );
        const competicao = document.getElementById ( 'arena-competicao' );
        
        fetch('http://localhost:8080/arenas', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                "id":"",
                "nome":nome.value,
                "competicao":{"id":competicao.value}
            })
        })
    }

    render(){
        return (
            <form id="arena-form">
                <label>Arena:</label>
                <input
                    id="arena-nome"
                    type="text"
                    name="nome"
                />
                <br/>
                <label>Competição:</label>
                <input
                    id="arena-competicao"
                    type="number"
                    name="competicao"
                />
                <button onClick={this.handleSalvar}>
                    Salvar
                </button>
            </form>

        )
    }
}

export default Arena;