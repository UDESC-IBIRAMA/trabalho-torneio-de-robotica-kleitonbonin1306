package com.CompeticaoRobotica.CompeticaoRobotica.models;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author kleiton Bonin
 */
@Entity
public class Temporada implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String nome;
    private String Descricao;
    private Set<Competicao> Competicaos;
    private Set<Rodada> Rodadas;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }
    
    @OneToMany(mappedBy = "temporada", cascade = CascadeType.ALL)
    public Set<Competicao> getCompeticao() {
        return Competicaos;
    }

    public void setCompeticao(Set<Competicao> Competicaos) {
        this.Competicaos = Competicaos;
    }
    
    @OneToMany(mappedBy = "temporada", cascade = CascadeType.ALL)
    public Set<Rodada> getRodadas() {
        return Rodadas;
    }

    public void setRodadas(Set<Rodada> Rodadas) {
        this.Rodadas = Rodadas;
    }

    @Override
    public String toString() {
        return "Temporada{" + "id=" + id + ", nome=" + nome + ", Descricao=" + Descricao + ", Juiz=" + Competicaos + '}';
    }

    
}
