package com.CompeticaoRobotica.CompeticaoRobotica.models;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author kleiton Bonin
 */
@Entity
public class RodadaEquipe implements Serializable {

    private static final long serialVersionUID = 1L;
  
    private Long id;
    private Long idRodada;
    private int idem;
    private Long alternativa;
    private Equipe equipe;
    private Arena arena;
    private Sala sala;
    

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    @Id
    public Long getIdRodada() {
        return idRodada;
    }

    public void setIdRodada(Long idRodada) {
        this.idRodada = idRodada;
    }

    public int getIdem() {
        return idem;
    }

    public void setIdem(int idem) {
        this.idem = idem;
    }

    public Long getAlternativa() {
        return alternativa;
    }

    public void setAlternativa(Long alternativa) {
        this.alternativa = alternativa;
    }
    
    @ManyToOne
    @JoinColumn(name = "Equipe_id")
    public Equipe getEquipe() {
        return equipe;
    }

    public void setEquipe(Equipe equipe) {
        this.equipe = equipe;
    }
    @ManyToOne
    @JoinColumn(name = "Arena_id")
    public Arena getArena() {
        return arena;
    }

    public void setArena(Arena arena) {
        this.arena = arena;
    }
    @ManyToOne
    @JoinColumn(name = "Sala_id")
    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RodadaEquipe)) {
            return false;
        }
        RodadaEquipe other = (RodadaEquipe) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.CompeticaoRobotica.CompeticaoRobotica.models.Rodada[ id=" + id + " ]";
    }
    
}
