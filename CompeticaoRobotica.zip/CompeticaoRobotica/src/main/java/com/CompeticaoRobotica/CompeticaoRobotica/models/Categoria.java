package com.CompeticaoRobotica.CompeticaoRobotica.models;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author kleiton Bonin
 */
@Entity
public class Categoria implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String nome;
    private String descricao;
    private Set<Juiz> Juizes;
    private Set<Criterio> Criterios;
    private Set<Sala> Salas;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL)
    public Set<Juiz> getJuiz() {
        return Juizes;
    }

    public void setJuiz(Set<Juiz> Juizes) {
        this.Juizes = Juizes;
    }
    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL)
    public Set<Criterio> getCriterios() {
        return Criterios;
    }

    public void setCriterios(Set<Criterio> Criterios) {
        this.Criterios = Criterios;
    }
    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL)
    public Set<Sala> getSala() {
        return Salas;
    }

    public void setSala(Set<Sala> Salas) {
        this.Salas = Salas;
    }
    
    @Override
    public String toString() {
        return "Categoria{" + "id=" + id + ", nome=" + nome + ", Descricao=" + descricao + ", Juiz=" + Juizes + '}';
    }

    
}
